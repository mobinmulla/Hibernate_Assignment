package com.cg.labOne.dao;

import javax.persistence.EntityManager;

import com.cg.labOne.bean.Author;

public class AuthorDao implements AuthorDaoInterface{
	
	private EntityManager entityManager;
	
	public AuthorDao() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public void addAuthor(Author author) {
		entityManager.persist(author);
		System.out.println("Author ID is:" + author.getAuthorId());
		
	}
	
	@Override
	public void updateAuthor(int id, int option, String newValue, int nameUpdate) {
		Author author = entityManager.find(Author.class, id);
		
		switch (option) {
		case 1:	
			switch (nameUpdate) {
			case 1:
				author.setFirstName(newValue);
				break;
			case 2:
				author.setMiddleName(newValue);
				break;
			case 3:
				author.setLastName(newValue);
				break;

			default:
				break;
			}
			break;
		case 2:
			author.setPhoneNo(newValue);

		default:
			break;
		}
		entityManager.merge(author);
		System.out.println("the value updated successfullllyllyllylyl!");
		
		
	}

	@Override
	public void beginTansaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTansaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void showAuthor(int id) {
		Author author = entityManager.find(Author.class, id);
		System.out.println(author);
		
	}

	@Override
	public void deleteAuthor(int id) {
		 Author author = entityManager.find(Author.class, id);
	     entityManager.remove(author);
	     System.out.println("Author Removed Successfully....!!!!!");	
	}
}
