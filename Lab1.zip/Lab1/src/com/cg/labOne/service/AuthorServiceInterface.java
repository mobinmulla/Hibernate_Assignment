package com.cg.labOne.service;

import com.cg.labOne.bean.Author;

public interface AuthorServiceInterface {
	
	public abstract void addAuthor(Author author);
	
	public abstract void updateAuthor(int id, int option, String newValue, int nameUpdate);
	
	public abstract void showAuthor(int id);
	
	public abstract void deleteAuthor(int id);

}
