package com.cg.labOne.service;

import com.cg.labOne.bean.Author;
import com.cg.labOne.dao.AuthorDao;
import com.cg.labOne.dao.AuthorDaoInterface;

public class AuthorService implements AuthorServiceInterface {

	AuthorDaoInterface dao = new AuthorDao();
	
	@Override
	public void addAuthor(Author author) {
		dao.beginTansaction();
		dao.addAuthor(author);
		dao.commitTansaction();
	}

	@Override
	public void updateAuthor(int id, int option, String newValue, int nameUpdate) {
		dao.beginTansaction();
		dao.updateAuthor(id,option,newValue,nameUpdate);
		dao.commitTansaction();
	}

	@Override
	public void showAuthor(int id) {
		dao.showAuthor(id);
		
	}

	@Override
	public void deleteAuthor(int id) {
		dao.beginTansaction();
		dao.deleteAuthor(id);
		dao.commitTansaction();
		
	}

}
