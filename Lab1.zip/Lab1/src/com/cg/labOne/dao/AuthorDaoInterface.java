package com.cg.labOne.dao;

import com.cg.labOne.bean.Author;

public interface AuthorDaoInterface {
	
	public abstract void addAuthor(Author author);
	
	public abstract void updateAuthor(int id, int option, String newValue, int nameUpdate);
	
	public abstract void beginTansaction();
	
	public abstract void commitTansaction();

	public abstract void showAuthor(int id);

	public abstract void deleteAuthor(int id);

}
