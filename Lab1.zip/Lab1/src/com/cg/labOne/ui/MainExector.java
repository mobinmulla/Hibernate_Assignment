package com.cg.labOne.ui;

import java.util.Scanner;

import com.cg.labOne.bean.Author;
import com.cg.labOne.service.AuthorService;
import com.cg.labOne.service.AuthorServiceInterface;

public class MainExector {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		Author author = new Author();

		AuthorServiceInterface service = new AuthorService();

		String firstName;
		String middleName;
		String lastName;
		String phoneNo;
		int choice, nameUpdate = 0;
		int id, option;
		String newValue;

		for (;;) {
			System.out
					.println("1.Add Author\n2.Update Author Data\n3.Show Information\n4.Delete Author\n5.Exit");
			choice = input.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Author's First Name:");
				firstName = input.next();
				System.out.println("Enter Author's Middle Name:");
				middleName = input.next();
				System.out.println("Enter Author's Last Name:");
				lastName = input.next();
				System.out.println("Enter Author's Contact No.:");
				phoneNo = input.next();

				author.setFirstName(firstName);
				author.setMiddleName(middleName);
				author.setLastName(lastName);
				author.setPhoneNo(phoneNo);

				service.addAuthor(author);

				break;

			case 2:
				// Update Author
				System.out.println("Enter Author Id");
				id = input.nextInt();
				System.out.println("Update\n1.Name\n2.Contact");
				option = input.nextInt();
				switch (option) {
				case 1:
					System.out
							.println("Update\n1.First Name\n2.Middle Name\n3.Last Name");
					nameUpdate = input.nextInt();
					if (nameUpdate == 1) {
						System.out.println("Enter First Name");
						newValue = input.next();
						service.updateAuthor(id, option, newValue, nameUpdate);
					} else if (nameUpdate == 2) {
						System.out.println("Enter Middle Name");
						newValue = input.next();
						service.updateAuthor(id, option, newValue, nameUpdate);
					} else if (nameUpdate == 3) {
						System.out.println("Enter Last Name");
						newValue = input.next();
						service.updateAuthor(id, option, newValue, nameUpdate);
					} else {
						System.out.println("Ghrala ja");
					}
					break;

				case 2:
					System.out.println("Enter Contact No.:");
					newValue = input.next();
					service.updateAuthor(id, option, newValue, nameUpdate);

					break;
				default:
					System.out.println("Invalid Choice");
					break;
				}
				break;

			case 3:

				System.out.println("Enter Author ID:");
				id = input.nextInt();
				service.showAuthor(id);
				break;

			case 4:
				System.out.println("Enter Author ID:");
				id = input.nextInt();
				service.deleteAuthor(id);
				break;
			case 5:
				System.out.println("Thank you...!!!");
				System.exit(0);
				break;
			}
		}

	}
}
